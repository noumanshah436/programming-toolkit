#include <iostream>
using namespace std;

int main( )
{
	unsigned long long int la = 0;
	
	cin >> la;
	if (la < 4294967295)  //  i.e ( 2 raies power 32 ) -1
	{
		cout << "The address " << la << " contains:";
		cout << "\npage number = " << la / 4096;
		cout << "\noffset = " << la % 4096;
	}
	else
	{
		cout << "\nPlease input Valid memory bound between 0 -  4294967295\n ";
	}
	
	return 0;
}
