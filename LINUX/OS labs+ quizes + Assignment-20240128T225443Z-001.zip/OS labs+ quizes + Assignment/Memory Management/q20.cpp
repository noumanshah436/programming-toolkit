#include <iostream>
#include <string>
using namespace std;

class FrameList {
	int* page;
	int frameSize;
	int noOfHits;
	int noOfMisses;
	int noOfElements;

public:
	FrameList(int);
	int indexFinder(int);
	void display();
	void FIFO(string);
	void LRU(string);
	~FrameList();
};

int main()
{
	int frameSize;
	cout << "Enter Frames Size: "; cin >> frameSize;
	string pageList;
	cout << "Enter Page List: "; cin >> pageList;
	FrameList q20(frameSize);
	q20.FIFO(pageList);
	q20.LRU(pageList);
	return 0;
}

FrameList::FrameList(int frameSize)
{
	if (frameSize <= 0)
	{
		return;
	}
	this->frameSize = frameSize;
	noOfElements = 0;
	noOfHits = 0;
	noOfMisses = 0;
	page = new int[this->frameSize];
}
int FrameList::indexFinder(int key)
{
	int i = 0;
	while (i < noOfElements && key != page[i])
		i++;
	return i < noOfElements ? i : -1;
}
void FrameList::display()
{
	cout << "\nTotal Hits: " << noOfHits;
	cout << "\nTotal Miss: " << noOfMisses;
	cout << "\nPage Faults: " << noOfMisses;
	cout << "\nHit Rate: " << double(noOfHits) / (double)(noOfHits + noOfMisses);
	cout << "\nMiss Rate: " << double(noOfMisses) / (double)(noOfHits + noOfMisses);
}
void FrameList::FIFO(string pageList)
{
	cout << "\n\t\t\tFIFO";
	noOfElements = 0;
	noOfHits = 0;
	noOfMisses = 0;
	int i = 0;
	while (pageList[i])
	{
		if (indexFinder(pageList[i] - '0') == -1)
		{
			noOfMisses++;
			if (noOfElements < frameSize)
				noOfElements++;
			else
				for (int i = 1; i < frameSize; i++)
					page[i - 1] = page[i];

			page[noOfElements - 1] = pageList[i] - '0';
		}
		else
		{
			noOfHits++;
		}
		i++;
	}
	display();
}
void FrameList::LRU(string pageList)
{
	cout << "\n\t\t\tLRU";
	noOfElements = 0;
	noOfHits = 0;
	noOfMisses = 0;
	int i = 0;
	while (pageList[i])
	{
		int temp = indexFinder(pageList[i] - '0');
		if (temp == -1)
		{
			noOfMisses++;
			temp = noOfElements;
			if (noOfElements < frameSize)
				noOfElements++;
		}
		else
		{
			noOfHits++;
		}
		while (temp > 0)
		{
			page[temp] = page[temp - 1];
			temp--;
		}
		page[0] = pageList[i] - '0';
		i++;
	}
	display();
}
FrameList::~FrameList()
{
	if (frameSize > 0)
	{
		delete[] page;
	}
	frameSize = 0;
}