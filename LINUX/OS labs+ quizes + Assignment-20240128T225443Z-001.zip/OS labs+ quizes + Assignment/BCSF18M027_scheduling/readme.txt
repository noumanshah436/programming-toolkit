**Execution Description**
Three queues are used as MFQ's(queue0, queue1,queue2)
PID of processes starts from 1 to n.
User  Enter Arrival Time and Burst time of each process from console input.
The processes that terminate in each queue will be displayed as output.
Process class is used to store all the attributes of the process.

In queue0 if process terminates its PID , BT(burst time), WT(waiting time) , TAT(turnaround Time) is displayed.
OtherWise it moves to queue1 and if it terminates there, it shows its output.
At last for SRTF I implement the Insertion sort on queue2 which sort processes according to their remaining time in ascending order.
and process will execute one after another.
 




**Sample Run 1**

Enter # of Processes :6
Enter Arrival Time and Burst time of Process  1 :0 60
Enter Arrival Time and Burst time of Process  2 :25 120
Enter Arrival Time and Burst time of Process  3 :30 250
Enter Arrival Time and Burst time of Process  4 :45 40
Enter Arrival Time and Burst time of Process  5 :50 100
Enter Arrival Time and Burst time of Process  6 :60 300

Process terminated in Queue0 of Time Quantum 50 ms
PID             BT              WT              TAT
4               40              105             145

Process terminated in Queue1 of Time Quantum 100 ms
PID             BT              WT              TAT
1               60              240             300
2               120             225             345
5               100             370             470

Process terminated in Queue2 of Time Quantum 100 ms
3               250             440             690
6               300             510             810

Avg Wait Time : 460
Avg response Time : 86





**Sample Run 2**


Enter # of Processes :5
Enter Arrival Time and Burst time of Process  1 :0 80
Enter Arrival Time and Burst time of Process  2 :10 90
Enter Arrival Time and Burst time of Process  3 :20 100
Enter Arrival Time and Burst time of Process  4 :30 150
Enter Arrival Time and Burst time of Process  5 :40 120

Process terminated in Queue0 of Time Quantum 50 ms
PID             BT              WT              TAT

Process terminated in Queue1 of Time Quantum 100 ms
PID             BT              WT              TAT
1               80              200             280
2               90              220             310
3               100             250             350
4               150             290             440
5               120             380             500

Process terminated in Queue2 of Time Quantum 100 ms

Avg Wait Time : 376
Avg response Time : 80




