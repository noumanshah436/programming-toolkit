#include<iostream>
using namespace std;

// bcsf18m027
// Syed Nouman rehman
class Process
{
public:
	
	int PID,arrival_Time, burst_Time, remaining_Time, wait_Time,finish_Time, turnaround_Time,response_Time;
	
}
queue0[10], queue1[10], queue2[10];

int sum_response_Time=0, sum_Turnaround_Time=0;
int n;


int main()
{
	int total_time = 0;     //   store the current time of execution i.e. time elapsed 
	int nextIndexToMoveProcessInQueue1 = 0;
	int nextIndexToMoveProcessInQueue2 = 0; 
	

	cout << "Enter # of Processes :";
	cin >> n;

	int quantum1 = 50, quantum2 = 100, quantum3 = 200;

	for (int i = 0; i < n; i++)   //  set PID and and take arrival and burst time from user
	{
		queue0[i].PID = i+1;
		cout << "Enter Arrival Time and Burst time of Process  "<< queue0[i].PID<<" :";
		cin >> queue0[i].arrival_Time >> queue0[i].burst_Time;
		queue0[i].remaining_Time = queue0[i].burst_Time;

	}
	

	cout<<"\nProcess terminated in Queue0 of Time Quantum 50 ms";
	cout<<"\nPID\t\tBT\t\tWT\t\tTAT\t\t";

	//  execute queue0
	for (int i = 0; i < n; i++)
	{
		if (queue0[i].burst_Time <= quantum1)
		{
			queue0[i].response_Time = total_time- queue0[i].arrival_Time;
			total_time = total_time + queue0[i].burst_Time;
			queue0[i].finish_Time = total_time;
			queue0[i].remaining_Time = 0;
			queue0[i].wait_Time = queue0[i].finish_Time - queue0[i].arrival_Time - queue0[i].burst_Time;
			// wait time=  finishTime -arrival -burstTime
			queue0[i].turnaround_Time = queue0[i].finish_Time - queue0[i].arrival_Time;
			//  turnArountTime =  finishtime -  arrivalTime

			

			sum_Turnaround_Time = sum_Turnaround_Time + queue0[i].turnaround_Time;
			sum_response_Time = sum_response_Time + queue0[i].response_Time;
			cout << "\n" << queue0[i].PID << "\t\t" << queue0[i].burst_Time << "\t\t" << queue0[i].wait_Time << "\t\t" << queue0[i].turnaround_Time;

		}
		
		else    //  if (queue0[i].burst_Time > quantum1)
		{
			queue0[i].response_Time = total_time - queue0[i].arrival_Time;
			queue0[i].remaining_Time = queue0[i].burst_Time - quantum1;
			total_time = total_time + quantum1;
			

			sum_response_Time = sum_response_Time + queue0[i].response_Time;

			queue1[nextIndexToMoveProcessInQueue1] = queue0[i];
			nextIndexToMoveProcessInQueue1++;
		}

	}

	cout<<"\n\nProcess terminated in Queue1 of Time Quantum 100 ms";
	cout << "\nPID\t\tBT\t\tWT\t\tTAT\t\t";

	
	//  execute queue1
	int totalElementsInQueue1 = nextIndexToMoveProcessInQueue1;

	for (int i = 0; i < totalElementsInQueue1; i++)
	{
		if (queue1[i].remaining_Time <= quantum2)
		{
			total_time = total_time + queue1[i].remaining_Time;
			queue1[i].finish_Time = total_time;
			queue1[i].remaining_Time = 0;
			queue1[i].wait_Time = queue1[i].finish_Time - queue1[i].arrival_Time - queue1[i].burst_Time;
			// wait time=  finishTime -arrival -burstTime
			queue1[i].turnaround_Time = queue1[i].finish_Time - queue1[i].arrival_Time;
			//  turnArountTime =  finishtime -  arrivalTime
			

			sum_Turnaround_Time = sum_Turnaround_Time + queue1[i].turnaround_Time;

			cout<<"\n"<<queue1[i].PID<<"\t\t"<< queue1[i].burst_Time << "\t\t" << queue1[i].wait_Time<<"\t\t"<<queue1[i].turnaround_Time;
		}
		else    //  if queu1[i] still not complete
		{
			queue1[i].remaining_Time = queue1[i].remaining_Time - quantum2;
			total_time = total_time + quantum2;
			queue2[nextIndexToMoveProcessInQueue2] = queue1[i];
			nextIndexToMoveProcessInQueue2++;
		}
	}
	
	//   use insertion sort to sort process to run in SRTF according to their remaining time in 
	int i, key, j;
	for (i = 1; i < nextIndexToMoveProcessInQueue2; i++)
	{
		key = queue2[i].remaining_Time;
		j = i - 1;

		while (j >= 0 && queue2[j].remaining_Time > key)
		{
			queue2[j + 1] = queue2[j];

			j = j - 1;
		}
		queue2[j + 1] = queue2[i];
	}
	//  insertion sort end
	


	cout << "\n\nProcess terminated in Queue2 of Time Quantum 100 ms ";

	//  execute queue2

	int totalElementsInQueue2 = nextIndexToMoveProcessInQueue2;
	for (int i = 0; i < totalElementsInQueue2; i++)
	{
		total_time = total_time + queue2[i].remaining_Time;
		queue2[i].finish_Time = total_time;
		queue2[i].remaining_Time = 0;
		queue2[i].wait_Time = queue2[i].finish_Time - queue2[i].arrival_Time - queue2[i].burst_Time;
		// wait time=  finishTime -arrival -burstTime
		queue2[i].turnaround_Time = queue2[i].finish_Time - queue2[i].arrival_Time;
		//  turnArountTime =  finishtime -  arrivalTime

		sum_Turnaround_Time = sum_Turnaround_Time + queue2[i].turnaround_Time;

		cout << "\n" << queue2[i].PID << "\t\t" << queue2[i].burst_Time << "\t\t" << queue2[i].wait_Time << "\t\t" << queue2[i].turnaround_Time;

	}

	cout << "\n\n";
	cout << "Avg Wait Time : " << sum_Turnaround_Time/n <<"\n";
	cout << "Avg response Time : " << sum_response_Time/n << "\n\n";
	
	return 0;
}

